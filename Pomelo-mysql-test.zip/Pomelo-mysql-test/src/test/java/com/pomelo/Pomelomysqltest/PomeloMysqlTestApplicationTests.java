package com.pomelo.Pomelomysqltest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PomeloMysqlTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
